SEED = 1
PROMISE_URL = 'http://promise.site.uottawa.ca/SERepository/datasets/'
